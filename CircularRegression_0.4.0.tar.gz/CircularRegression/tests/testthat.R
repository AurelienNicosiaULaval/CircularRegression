library(testthat)
library(CircularRegression)

test_check("CircularRegression")
