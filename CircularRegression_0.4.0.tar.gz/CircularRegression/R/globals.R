if (getRversion() >= "2.15.1") {
  utils::globalVariables(c("Fitted", "Residual", "density"))
}

